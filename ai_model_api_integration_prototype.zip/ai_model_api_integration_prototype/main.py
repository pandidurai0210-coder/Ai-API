import os
from google import genai
from dotenv import load_dotenv

# Load environment variables from a .env file if present
load_dotenv()


def initialize_client():
    """Initialize the GenAI client securely using an environment variable."""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY environment variable is not set. "
            "Please configure it in your .env file."
        )
    return genai.Client(api_key=api_key)


def run_prototype(prompt_text: str) -> str:
    """Send a prompt to Gemini and return the generated response."""
    client = initialize_client()

    print(f"\n[Input Prompt]: {prompt_text}")
    print("Generating response...")

    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt_text,
    )

    if not response.text:
        raise RuntimeError("The model returned an empty response.")

    return response.text


if __name__ == "__main__":
    sample_input = (
        "Explain the core concept of Retrieval-Augmented Generation (RAG) "
        "in 2 concise sentences for a beginner developer."
    )

    try:
        output = run_prototype(sample_input)
        print("\n--- Model Output ---")
        print(output)
        print("--------------------")
    except Exception as exc:
        print(f"\nAn error occurred: {exc}")
